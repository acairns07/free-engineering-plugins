# RCA Factory

## Scope and outcome

## Supplied evidence

## Findings

## Assumptions and unknowns

## Recommended actions

## Validation and follow-up
